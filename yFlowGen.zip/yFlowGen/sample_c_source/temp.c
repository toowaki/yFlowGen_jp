uint_8 chk1(void){
	unit8_t i=0;
	for(;;){
		i++;
		if(i>=5){
			break;
		}
	}
	return(0);
}

uint_8 chk2(void){
	unit8_t i=0;
	for(;;){
		i++;
		if(i>=5){
			break;
		}
		else;
	}
	return(0);
}
vector<int>::iterator partition(const vector<int> &A, 
                                const vector<int>::iterator &p,
                                const vector<int>::iterator &r) {
    // Get a random element within A[p:r].
    auto seed = clock() * clock() * clock();
    std::default_random_engine dre(seed);
    std::uniform_int_distribution<size_t> di(0, r - p);
 
    auto random_it = p;
    random_it = p + di(dre);
 
    // Swap values of random_it and r.
    auto tmp = *random_it;
    *random_it = *r;
    *r = tmp;
 
    auto pivot = *r;
 
    int iless = -1;
    for(int i = 0; i < r - p; i++) {
        if(*(p+i) <= pivot) {
            iless++;
            if(iless != i) {
                // Swap *(p+iless) and *(p+i)
                tmp = *(p+iless);
                *(p+iless) = *(p+i);
                *(p+i) = tmp;
            }
        }
    }
 
    // Swap *(p+iless+1) and *r
    *r = *(p+iless+1);
    *(p+iless+1) = pivot;
 
    return p + iless + 1;
}
 
 
//------------------------------------------------------------------------------
void quickSort(const vector<int> &A, const vector<int>::iterator &p,
                                     const vector<int>::iterator &r) {
    if(p < r) {
        auto q = partition(A, p, r);
        quickSort(A, p, q-1);
        quickSort(A, q+1, r);
    }
}
 
//------------------------------------------------------------------------------
int main(int argc, char *argv[]) {
    // Make a vector to hold a sample array.
    vector<int> A;
 
    // Set up random number generator.
    auto seed = clock() * clock() * clock();
    std::default_random_engine dre(seed); // engine
    std::uniform_int_distribution<int> di(0, 100); // distribution
 
    // Populate A with 10 random number in [0,100].
    int num = 10;
    for(int i = 0; i != num; i++) A.push_back(di(dre)); // Roll the die.
 
    // Original order.
    cout << \"Original order:\" << endl;
    for(auto it = A.begin(); it != A.end(); it++) 
        cout << *it << \" \";
    cout << endl;

    for(auto it = A.begin(); it != A.end(); it++) 
        cout << *it << \" \";

	
    // Sort.
    auto p = A.begin();
    auto r = A.end() - 1;
    quickSort(A, p, r);
 
    cout << \"Sorted order:\" << endl;
    for(auto it = A.begin(); it != A.end(); it++)
        cout << *it << \" \";
    cout << endl;
 
    return 0;
}

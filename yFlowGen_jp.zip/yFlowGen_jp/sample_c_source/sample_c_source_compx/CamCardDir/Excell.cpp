#if 0

#include "stdafx.h"
#include "CamCard.h"
#include "CamCardDlg.h"
#include <shlwapi.h>

#include "CApplication.h"
#include "CWorkbooks.h"
#include "CWorksheets.h"
#include "CWorkbook.h"
#include "CWorksheet.h"
#include "CRange.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif

CApplication app;
CWorkbooks books;

COleVariant NonOption((long)DISP_E_PARAMNOTFOUND, VT_ERROR);

void CCamCardDlg::CountCard(int code, int num)
{
	CStringA strFolderPath;
	CStringA strExsPath;
	CWorksheets sheets;
	CWorksheet sheet;
//	CRange r;
	CStringA str;
	CRange	cells;
	CRange	cell;
	char sz[1024];
	int row;
	int code2;
	int num2;

	//CoInitialize(NULL);//COM�𗘗p����X���b�h���ɌĂяo���Ȃ���΂Ȃ�Ȃ�API

	if (!app.CreateDispatch("Excel.Application")) return;
	
	app.put_Visible(TRUE);//�G�N�Z������ʂɕ\��
	books=app.get_Workbooks();

	books.Add(NonOption);//�V�����V�[�g���J��

	// exe�̃t�H���_�̃p�X���擾
	GetExeFolderPath(&strFolderPath);
	// �G�N�Z���̃p�X
	strExsPath = strFolderPath + "\\" + STOCK_FOLDER + "\\" + XLS_NAME;

	TRY {
	books.Open(strExsPath,
		NonOption,NonOption,NonOption,NonOption,NonOption,NonOption,
		NonOption,NonOption,NonOption,NonOption,NonOption,NonOption,NonOption,NonOption);
	}
	CATCH(CException, e) 
	{
		goto End;
	}
	END_CATCH

	app.put_UserControl(FALSE);	// ���[�U����֎~
	app.put_DisplayAlerts(FALSE);	// �㏑���A���[�g���o���Ȃ�

	sheets=app.get_Worksheets();
	sheet=sheets.get_Item(COleVariant((short)1));//��ڂ̃V�[�g��I��
	
	cells = sheet.get_Cells();
	row = 0;
	while (1)
	{
		row++;
		cell = cells.get_Item(COleVariant((long)row), COleVariant((long)1)).pdispVal;
		str = cell.get_Value2();
		strcpy(sz, str.GetBuffer());
		code2 = atoi(sz);
		if (code == code2)
		{
			cell.ReleaseDispatch();
	
			cell = cells.get_Item(COleVariant((long)row), COleVariant((long)2)).pdispVal;
			str = cell.get_Value2();
			strcpy(sz, str.GetBuffer());
			num2 = atoi(sz) + num;
			if (num2 < 0) num2 = 0;
			sprintf(sz, "%d", num2);
			cell.put_Value(COleVariant(), COleVariant(sz));
			cell.ReleaseDispatch();
			break;
		}
		if ((!code) || (strlen(sz) != 8))
		{
			/*
			cell.put_Value(COleVariant(), COleVariant("1"));
			cell.ReleaseDispatch();
			
			cell = cells.get_Item(COleVariant((long)row), COleVariant((long)2)).pdispVal;
			cell.put_Value(COleVariant(), COleVariant("1"));
			cell.ReleaseDispatch();*/
			break;
		}
		cell.ReleaseDispatch();
	}

	sheet.SaveAs(strExsPath,NonOption,NonOption,NonOption,//�t�@�C���֕ۑ�
		NonOption,NonOption,NonOption,NonOption,NonOption,NonOption);
	

End:;
	/*
	app.Quit();
	books.ReleaseDispatch();
	app.ReleaseDispatch();
	*/
	
	cells.ReleaseDispatch();
	sheet.ReleaseDispatch();
	sheets.ReleaseDispatch();
	//book.Close(COleVariant((short)FALSE), covOptional, covOptional);
	books.ReleaseDispatch();
	app.put_UserControl(TRUE);
	app.Quit();
	app.ReleaseDispatch();
}


#endif
#pragma once
#include "Dice.h"

namespace DiceGame {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Diagnostics;
	using namespace System::Collections::Generic;

	/// <summary>
	/// Form1 �̊T�v
	///
	/// �x��: ���̃N���X�̖��O��ύX����ꍇ�A���̃N���X���ˑ����邷�ׂĂ� .resx �t�@�C���Ɋ֘A�t����ꂽ
	///          �}�l�[�W ���\�[�X �R���p�C�� �c�[���ɑ΂��� 'Resource File Name' �v���p�e�B��
	///          �ύX����K�v������܂��B���̕ύX���s��Ȃ��ƁA
	///          �f�U�C�i�ƁA���̃t�H�[���Ɋ֘A�t����ꂽ���[�J���C�Y�ς݃��\�[�X�Ƃ��A
	///          ���������݂ɗ��p�ł��Ȃ��Ȃ�܂��B
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: �����ɃR���X�g���N�^ �R�[�h��ǉ����܂�
			//
		}

	protected:
		/// <summary>
		/// �g�p���̃��\�[�X�����ׂăN���[���A�b�v���܂��B
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::RadioButton^  radioButtonKisu;
	private: System::Windows::Forms::RadioButton^  radioButtonGusu;
	private: System::Windows::Forms::PictureBox^  pictureDice1;
	private: System::Windows::Forms::PictureBox^  pictureDice2;
	private: System::Windows::Forms::PictureBox^  pictureDice4;
	private: System::Windows::Forms::PictureBox^  pictureDice5;
	private: System::Windows::Forms::PictureBox^  pictureDice6;
	private: System::Windows::Forms::PictureBox^  pictureDice3;
	private: System::Windows::Forms::Label^  labelResult;
	private: System::Windows::Forms::PictureBox^  pictureWin;
	private: System::Windows::Forms::PictureBox^  pictureLose;
	private: System::Windows::Forms::Timer^  timer1;
	private: System::Windows::Forms::ListBox^  listBox1;

	private: System::ComponentModel::IContainer^  components;








	protected: 

	private:
		/// <summary>
		/// �K�v�ȃf�U�C�i�ϐ��ł��B
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// �f�U�C�i �T�|�[�g�ɕK�v�ȃ��\�b�h�ł��B���̃��\�b�h�̓��e��
		/// �R�[�h �G�f�B�^�ŕύX���Ȃ��ł��������B
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Form1::typeid));
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->radioButtonKisu = (gcnew System::Windows::Forms::RadioButton());
			this->radioButtonGusu = (gcnew System::Windows::Forms::RadioButton());
			this->pictureDice1 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureDice2 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureDice4 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureDice5 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureDice6 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureDice3 = (gcnew System::Windows::Forms::PictureBox());
			this->labelResult = (gcnew System::Windows::Forms::Label());
			this->pictureWin = (gcnew System::Windows::Forms::PictureBox());
			this->pictureLose = (gcnew System::Windows::Forms::PictureBox());
			this->timer1 = (gcnew System::Windows::Forms::Timer(this->components));
			this->listBox1 = (gcnew System::Windows::Forms::ListBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureDice1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureDice2))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureDice4))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureDice5))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureDice6))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureDice3))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureWin))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureLose))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->BackColor = System::Drawing::Color::LemonChiffon;
			this->label1->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->label1->Font = (gcnew System::Drawing::Font(L"�l�r �o�S�V�b�N", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(128)));
			this->label1->ForeColor = System::Drawing::Color::Brown;
			this->label1->Location = System::Drawing::Point(29, 18);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(129, 26);
			this->label1->TabIndex = 0;
			this->label1->Text = L"�{�N�Ə������悤�I\r\n�A�������œ_��2�{����";
			// 
			// button1
			// 
			this->button1->Font = (gcnew System::Drawing::Font(L"�l�r �S�V�b�N", 15.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(128)));
			this->button1->ForeColor = System::Drawing::Color::Green;
			this->button1->Location = System::Drawing::Point(29, 58);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(123, 38);
			this->button1->TabIndex = 1;
			this->button1->Text = L"�����J�n";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click_1);
			// 
			// radioButtonKisu
			// 
			this->radioButtonKisu->Appearance = System::Windows::Forms::Appearance::Button;
			this->radioButtonKisu->AutoSize = true;
			this->radioButtonKisu->Font = (gcnew System::Drawing::Font(L"�l�r �o�S�V�b�N", 9, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(128)));
			this->radioButtonKisu->Location = System::Drawing::Point(29, 108);
			this->radioButtonKisu->Name = L"radioButtonKisu";
			this->radioButtonKisu->Size = System::Drawing::Size(53, 22);
			this->radioButtonKisu->TabIndex = 2;
			this->radioButtonKisu->TabStop = true;
			this->radioButtonKisu->Text = L"���";
			this->radioButtonKisu->TextAlign = System::Drawing::ContentAlignment::MiddleCenter;
			this->radioButtonKisu->UseVisualStyleBackColor = true;
			this->radioButtonKisu->Click += gcnew System::EventHandler(this, &Form1::radio_Click);
			// 
			// radioButtonGusu
			// 
			this->radioButtonGusu->Appearance = System::Windows::Forms::Appearance::Button;
			this->radioButtonGusu->AutoSize = true;
			this->radioButtonGusu->Font = (gcnew System::Drawing::Font(L"�l�r �o�S�V�b�N", 9, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(128)));
			this->radioButtonGusu->Location = System::Drawing::Point(88, 108);
			this->radioButtonGusu->Name = L"radioButtonGusu";
			this->radioButtonGusu->Size = System::Drawing::Size(53, 22);
			this->radioButtonGusu->TabIndex = 3;
			this->radioButtonGusu->TabStop = true;
			this->radioButtonGusu->Text = L"������";
			this->radioButtonGusu->TextAlign = System::Drawing::ContentAlignment::MiddleCenter;
			this->radioButtonGusu->UseVisualStyleBackColor = true;
			this->radioButtonGusu->Click += gcnew System::EventHandler(this, &Form1::radio_Click);
			// 
			// pictureDice1
			// 
			this->pictureDice1->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureDice1.Image")));
			this->pictureDice1->Location = System::Drawing::Point(69, 156);
			this->pictureDice1->Name = L"pictureDice1";
			this->pictureDice1->Size = System::Drawing::Size(32, 31);
			this->pictureDice1->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->pictureDice1->TabIndex = 4;
			this->pictureDice1->TabStop = false;
			this->pictureDice1->Visible = false;
			// 
			// pictureDice2
			// 
			this->pictureDice2->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureDice2.Image")));
			this->pictureDice2->Location = System::Drawing::Point(69, 156);
			this->pictureDice2->Name = L"pictureDice2";
			this->pictureDice2->Size = System::Drawing::Size(32, 31);
			this->pictureDice2->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->pictureDice2->TabIndex = 5;
			this->pictureDice2->TabStop = false;
			this->pictureDice2->Visible = false;
			// 
			// pictureDice4
			// 
			this->pictureDice4->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureDice4.Image")));
			this->pictureDice4->Location = System::Drawing::Point(69, 156);
			this->pictureDice4->Name = L"pictureDice4";
			this->pictureDice4->Size = System::Drawing::Size(32, 31);
			this->pictureDice4->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->pictureDice4->TabIndex = 6;
			this->pictureDice4->TabStop = false;
			this->pictureDice4->Visible = false;
			// 
			// pictureDice5
			// 
			this->pictureDice5->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureDice5.Image")));
			this->pictureDice5->Location = System::Drawing::Point(69, 156);
			this->pictureDice5->Name = L"pictureDice5";
			this->pictureDice5->Size = System::Drawing::Size(32, 31);
			this->pictureDice5->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->pictureDice5->TabIndex = 7;
			this->pictureDice5->TabStop = false;
			this->pictureDice5->Visible = false;
			// 
			// pictureDice6
			// 
			this->pictureDice6->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureDice6.Image")));
			this->pictureDice6->Location = System::Drawing::Point(69, 156);
			this->pictureDice6->Name = L"pictureDice6";
			this->pictureDice6->Size = System::Drawing::Size(32, 31);
			this->pictureDice6->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->pictureDice6->TabIndex = 8;
			this->pictureDice6->TabStop = false;
			this->pictureDice6->Visible = false;
			// 
			// pictureDice3
			// 
			this->pictureDice3->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureDice3.Image")));
			this->pictureDice3->Location = System::Drawing::Point(69, 156);
			this->pictureDice3->Name = L"pictureDice3";
			this->pictureDice3->Size = System::Drawing::Size(32, 31);
			this->pictureDice3->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->pictureDice3->TabIndex = 9;
			this->pictureDice3->TabStop = false;
			this->pictureDice3->Visible = false;
			// 
			// labelResult
			// 
			this->labelResult->AutoSize = true;
			this->labelResult->BackColor = System::Drawing::Color::Transparent;
			this->labelResult->Font = (gcnew System::Drawing::Font(L"�l�r �o�S�V�b�N", 36, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(128)));
			this->labelResult->Location = System::Drawing::Point(179, 229);
			this->labelResult->Name = L"labelResult";
			this->labelResult->Size = System::Drawing::Size(0, 48);
			this->labelResult->TabIndex = 10;
			// 
			// pictureWin
			// 
			this->pictureWin->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureWin.Image")));
			this->pictureWin->Location = System::Drawing::Point(29, 210);
			this->pictureWin->Name = L"pictureWin";
			this->pictureWin->Size = System::Drawing::Size(105, 91);
			this->pictureWin->SizeMode = System::Windows::Forms::PictureBoxSizeMode::AutoSize;
			this->pictureWin->TabIndex = 11;
			this->pictureWin->TabStop = false;
			this->pictureWin->Visible = false;
			// 
			// pictureLose
			// 
			this->pictureLose->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureLose.Image")));
			this->pictureLose->Location = System::Drawing::Point(29, 210);
			this->pictureLose->Name = L"pictureLose";
			this->pictureLose->Size = System::Drawing::Size(105, 91);
			this->pictureLose->SizeMode = System::Windows::Forms::PictureBoxSizeMode::AutoSize;
			this->pictureLose->TabIndex = 12;
			this->pictureLose->TabStop = false;
			this->pictureLose->Visible = false;
			// 
			// timer1
			// 
			this->timer1->Interval = 50;
			this->timer1->Tick += gcnew System::EventHandler(this, &Form1::timer1_Tick);
			// 
			// listBox1
			// 
			this->listBox1->BackColor = System::Drawing::Color::LemonChiffon;
			this->listBox1->Font = (gcnew System::Drawing::Font(L"�l�r �S�V�b�N", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(128)));
			this->listBox1->FormattingEnabled = true;
			this->listBox1->Location = System::Drawing::Point(214, 60);
			this->listBox1->Name = L"listBox1";
			this->listBox1->Size = System::Drawing::Size(200, 160);
			this->listBox1->TabIndex = 13;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 12);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"$this.BackgroundImage")));
			this->ClientSize = System::Drawing::Size(434, 313);
			this->Controls->Add(this->listBox1);
			this->Controls->Add(this->pictureDice1);
			this->Controls->Add(this->pictureLose);
			this->Controls->Add(this->pictureWin);
			this->Controls->Add(this->labelResult);
			this->Controls->Add(this->pictureDice3);
			this->Controls->Add(this->pictureDice6);
			this->Controls->Add(this->pictureDice5);
			this->Controls->Add(this->pictureDice4);
			this->Controls->Add(this->pictureDice2);
			this->Controls->Add(this->radioButtonGusu);
			this->Controls->Add(this->radioButtonKisu);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->label1);
			this->MaximizeBox = false;
			this->MinimizeBox = false;
			this->Name = L"Form1";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"�T�C�R���\�z�Q�[��";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			this->FormClosing += gcnew System::Windows::Forms::FormClosingEventHandler(this, &Form1::Form1_FormClosing);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureDice1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureDice2))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureDice4))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureDice5))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureDice6))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureDice3))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureWin))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureLose))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private:
	//Dice�N���X
	Dice^ _dice;
	//�_���v�Z�p�̃R���N�V����
		List<int>^ _historyCollection;

	private: System::Void button1_Click_1(System::Object^  sender, System::EventArgs^  e) {
				 //�e�R���g���[�����Q�[�����̏�ԂɕύX
				 ChangeControlStatus(true);
		 }

	private: System::Void ShowDice(int showDiceNumber){
				 //�S���̃T�C�R�����\��
				 this->pictureDice1->Visible = false;
				 this->pictureDice2->Visible = false;
				 this->pictureDice3->Visible = false;
				 this->pictureDice4->Visible = false;
				 this->pictureDice5->Visible = false;
				 this->pictureDice6->Visible = false;
				 //�T�C�R����\��
				 switch(showDiceNumber){
					 case 1:
						 this->pictureDice1->Visible = true;
						 break;
					 case 2:
						 this->pictureDice2->Visible = true;
						 break;
					 case 3:
						 this->pictureDice3->Visible = true;
						 break;
					 case 4:
						 this->pictureDice4->Visible = true;
						 break;
					 case 5:
						 this->pictureDice5->Visible = true;
						 break;
					 case 6:
						 this->pictureDice6->Visible = true;
						 break;
					 default:
						 break;
				 }

			 }

	private : bool IsWinGame(int showDiceNumber){

				  //��������̂ǂ����I�񂾂��ۑ�
				  String^ selectedValue;
				  if (radioButtonGusu->Checked == true){
					  selectedValue = "����";
				  }else{
					  selectedValue = "�";
				  }
				  //��������̂ǂ���̖ڂ��o������ۑ�
				  String^ resultValue;
				  if (showDiceNumber % 2 == 0){
					  resultValue = "����";
				  }else{
					  resultValue = "�";
				  }

				  //�\�z�ƌ��ʂ���v���邩�ŏ��s�𔻒�
				  if (selectedValue == resultValue){
					  //����
					  return true;
				  }else{
					  //����
					  return false;
				  }
			  }

	private: System::Void ShowPicture(bool winGame){

				 if (winGame){
					 this->labelResult->Text = "������I";
					 this->labelResult->ForeColor = Color::Red;
					 this->pictureWin->Visible = true;
					 this->pictureLose->Visible = false;
					 this->BackColor = Color::LightBlue;

				 }else{
					 this->labelResult->Text = "�͂���c";
					 this->labelResult->ForeColor = Color::Black;
					 this->pictureWin->Visible = false;
					 this->pictureLose->Visible = true;
					 this->BackColor = Color::Gray;
				 }
			 }

private: System::Void Form1_FormClosing(System::Object^  sender, System::Windows::Forms::FormClosingEventArgs^  e) {
				 if ( System::Windows::Forms::DialogResult::Cancel == 
					 MessageBox::Show("�Q�[�����I�����܂����H","�m�F",
					 MessageBoxButtons::OKCancel,MessageBoxIcon::Question))
				 {
					 e->Cancel = true;
				 }
		 }
private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {
			 _dice = gcnew Dice(6);
			 ShowDice(_dice->Number);
			 ChangeControlStatus(false);
			 _historyCollection = gcnew List<int>;
		 }

private: System::Void timer1_Tick(System::Object^  sender, System::EventArgs^  e) {
			 //�T�C�R����U��
			 _dice->Shake();
			 //�\���𔽉f����
			 ShowDice(_dice->Number);
		 }
private: System::Void ChangeControlStatus(bool playing){
			 //�T�C�R���p�̃^�C�}�[
			 timer1->Enabled = playing;
			 //�����J�n�{�^��
			 this->button1->Enabled = !playing;
			 //��E�����{�^��
			 this->radioButtonKisu->Enabled = playing;
			 this->radioButtonGusu->Enabled = playing;
			 if (playing){
				 this->radioButtonGusu->Checked = false;
				 this->radioButtonKisu->Checked = false;
			 }
		 }
private: System::Void ManageHistory(bool winGame){
			 //����̓��_�p�ϐ�
			 int nowPoint = 0;
			 if (winGame) {
				 //���݂̃Q�[�������擾
				 int gameCount = _historyCollection->Count;
				 //�O��̓��_�p�ϐ�
				 int prePoint = 0;
				 if (gameCount > 0){
					 //1��ȏ�Q�[�������Ă���ΑO��̓_����ݒ�
					 prePoint = _historyCollection[gameCount - 1];
				 }
				 //����̓��_�v�Z
				 if (prePoint == 0) {
					 //�O�񕉂��Ă����1�_
					 nowPoint = 1;
				 }else{
					 //�O�񏟂��Ă����2�{
					 nowPoint = prePoint * 2;
				 }
			 }

			 //���X�g�{�b�N�X�ɒǉ�
			 if ((_dice->Number % 2) == 0) {
				 this->listBox1->Items->Add("�����ł��B" + labelResult->Text + "�F" + nowPoint.ToString() + "�_");
			 }else{
				 this->listBox1->Items->Add("��ł��B" + labelResult->Text + "�F"  + nowPoint.ToString() + "�_");
			 }

			 //�R���N�V�����ɃQ�[���̗�����ǉ�
			 _historyCollection->Add(nowPoint);
			 //10��Q�[��������΁A���ʂ��W�v����
				 if (_historyCollection->Count == 10){
					 //��������
					 int winCount = 0;
					 //��������
					 int loseCount = 0;
					 //���v���_
					 int sumPoint = 0;
					 //�Y��
					 int i = 0;
					 //10��J��Ԃ�
					 while (i < _historyCollection->Count){
						 //�R���N�V�������痚���̎��o��
						 int historyPoint = _historyCollection[i];
						 //���v���_�𑫂�����
						 sumPoint = sumPoint + historyPoint;
						 //���������ƕ��������̉��Z
						 if (historyPoint == 0) {
							 loseCount++;
						 }else{
							 winCount++;
						 }
						 i++;
					 }
					 MessageBox::Show("���v���_��" + sumPoint + "�_�ł���",winCount +"��" + loseCount + "�s");
					 //�����J�n�{�^�����g�p�s��
					 this->button1->Enabled = false;
				 }
		 }



private: System::Void radio_Click(System::Object^  sender, System::EventArgs^  e) {
			 //�e�R���g���[�����Q�[���I���̏�ԂɕύX
			 ChangeControlStatus(false);
			 //���s�̔���
			 bool winflg = IsWinGame(_dice->Number);
			 //���s�摜�̕\��
			 ShowPicture(winflg);
			 //�����̊Ǘ�
			 ManageHistory(winflg);
		 }
};
}


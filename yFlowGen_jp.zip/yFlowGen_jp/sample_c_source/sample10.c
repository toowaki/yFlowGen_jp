namespace my_space {
  // �Ǝ��z��
  struct MyArray{ int a;/* ... */};
  // MyArray��pbegin
  decltype(atuo) begin(const MyArray& a) { return /* ... */; }
}

template < class Range >
void f(Range&& range){
  using std::begin;
  auto first = begin(range);
}
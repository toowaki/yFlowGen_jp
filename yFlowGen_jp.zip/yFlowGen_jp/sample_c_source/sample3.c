sub1()
{
	//test1
	if(cout>5) count=8;
	else 	pos=(3+1);

	//test1
	if(cout>5) count=8;
	else 	{
		pos=(3+1);
	}

	//test1
	if(cout>5) count=8;
	else 	{
		pos=(3+1);}a=a+1;

	//test2
	if(cout>5) count=8;
	else if(cout>2) count=2;
	else 
	pos=(3+1);

	//test3
	if(cout>5) count=8;
	else 	pos=3;

}

void main(void) {
	int a=0;
	a = 
	a + 1;
}

sub2()
{
	if(cout>5) count=8;
	else pos=3;}
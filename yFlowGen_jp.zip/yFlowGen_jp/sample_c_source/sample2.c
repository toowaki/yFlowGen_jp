#include <iostream>
using namespace std;

template <class Type> 
void myswap( Type &a, Type &b )
{
if(w<=0){
if(x<=0){
if(y<=0){
	if(z<1){
		Type temp = a;
		printf("}}�̏����p");
		a = b;
		b = temp;}}
}}}
sub5()
{
   if (i==0) i=1;
   else
   printf("(");
}

sub6()
{
   if (i==0) {
      if (j==0) k=1;
      else
      k=2; }}
	
sub7()
{
   if (i==0) {
   	if (j==0){
   		//none
   	}else if(a=1){
   		//none
   	}else
      k=2;
   	}}

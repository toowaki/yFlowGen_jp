sub5()
{
   if (i==0) i=1;
   else
   printf("(");
}

sub6()
{
   if (i==0) {
      if (j==0) k=1;
      else
      k=2; }}
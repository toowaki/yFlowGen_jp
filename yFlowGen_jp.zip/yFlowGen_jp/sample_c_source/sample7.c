 int sub7(){
            /* Process each node in the intersection table */
            for (ItNode intersect = it_table.top_node ; (intersect != null); intersect = intersect.next)
            {
               e0= intersect.ie[0];
               e1= intersect.ie[1];
               
               /* Only generate output for contributing intersections */
               if ( ((e0.bundle[ABOVE][CLIP]!=0) || (e0.bundle[ABOVE][SUBJ]!=0)) &&
                    ((e1.bundle[ABOVE][CLIP]!=0) || (e1.bundle[ABOVE][SUBJ]!=0)))
               {
                  PolygonNode p = e0.outp[ABOVE];
                  PolygonNode q = e1.outp[ABOVE];
                  double ix = intersect.point.x;
                  double iy = intersect.point.y + yb;
               
                  int in_clip = ( ( (e0.bundle[ABOVE][CLIP]!=0) && !(e0.bside[CLIP]!=0)) ||
                                  ( (e1.bundle[ABOVE][CLIP]!=0) &&  (e1.bside[CLIP]!=0)) ||
                                  (!(e0.bundle[ABOVE][CLIP]!=0) && !(e1.bundle[ABOVE][CLIP]!=0) &&
                                    (e0.bside[CLIP]!=0) && (e1.bside[CLIP]!=0) ) ) ? 1 : 0;
                  
                  int in_subj = ( ( (e0.bundle[ABOVE][SUBJ]!=0) && !(e0.bside[SUBJ]!=0)) ||
                                  ( (e1.bundle[ABOVE][SUBJ]!=0) &&  (e1.bside[SUBJ]!=0)) ||
                                  (!(e0.bundle[ABOVE][SUBJ]!=0) && !(e1.bundle[ABOVE][SUBJ]!=0) &&
                                    (e0.bside[SUBJ]!=0) && (e1.bside[SUBJ]!=0) ) ) ? 1 : 0;
        
                  int tr=0, tl=0, br=0, bl=0 ;
                  /* Determine quadrant occupancies */
                  if( (op == OperationType.GPC_DIFF) || (op == OperationType.GPC_INT) )
                  {
                     tr= ((in_clip!=0) && (in_subj!=0)) ? 1 : 0;
                     tl= (((in_clip ^ e1.bundle[ABOVE][CLIP])!=0) && ((in_subj ^ e1.bundle[ABOVE][SUBJ])!=0))?1:0;
                     br= (((in_clip ^ e0.bundle[ABOVE][CLIP])!=0) && ((in_subj ^ e0.bundle[ABOVE][SUBJ])!=0))?1:0;
                     bl= (((in_clip ^ e1.bundle[ABOVE][CLIP] ^ e0.bundle[ABOVE][CLIP])!=0) &&
                          ((in_subj ^ e1.bundle[ABOVE][SUBJ] ^ e0.bundle[ABOVE][SUBJ])!=0) ) ? 1:0;
                  }
                  else if( op == OperationType.GPC_XOR )
                  {
                     tr= (in_clip)^ (in_subj);
                     tl= (in_clip ^ e1.bundle[ABOVE][CLIP]) ^ (in_subj ^ e1.bundle[ABOVE][SUBJ]);
                     br= (in_clip ^ e0.bundle[ABOVE][CLIP]) ^ (in_subj ^ e0.bundle[ABOVE][SUBJ]);
                     bl= (in_clip ^ e1.bundle[ABOVE][CLIP] ^ e0.bundle[ABOVE][CLIP])
                       ^ (in_subj ^ e1.bundle[ABOVE][SUBJ] ^ e0.bundle[ABOVE][SUBJ]);
                  }
                  else if( op == OperationType.GPC_UNION )
                  {
                     tr= ((in_clip!=0) || (in_subj!=0)) ? 1 : 0;
                     tl= (((in_clip ^ e1.bundle[ABOVE][CLIP])!=0) || ((in_subj ^ e1.bundle[ABOVE][SUBJ])!=0)) ? 1 : 0;
                     br= (((in_clip ^ e0.bundle[ABOVE][CLIP])!=0) || ((in_subj ^ e0.bundle[ABOVE][SUBJ])!=0)) ? 1 : 0;
                     bl= (((in_clip ^ e1.bundle[ABOVE][CLIP] ^ e0.bundle[ABOVE][CLIP])!=0) ||
                          ((in_subj ^ e1.bundle[ABOVE][SUBJ] ^ e0.bundle[ABOVE][SUBJ])!=0)) ? 1 : 0;
                  }
                  else
                  {
                     throw new IllegalStateException("Unknown op type, "+op);
                  }
                  
                  int vclass = VertexType.getType( tr, tl, br, bl );
                  switch (vclass)
                  {
                     case VertexType.EMN:
                        e0.outp[ABOVE] = out_poly.add_local_min(ix, iy);
                        e1.outp[ABOVE] = e0.outp[ABOVE];
                        break;
                     case VertexType.ERI:
                        if (p != null)
                        {
                           p.add_right(ix, iy);
                           e1.outp[ABOVE]= p;
                           e0.outp[ABOVE]= null;
                        }
                        break;
                     case VertexType.ELI:
                        if (q != null)
                        {
                           q.add_left(ix, iy);
                           e0.outp[ABOVE]= q;
                           e1.outp[ABOVE]= null;
                        }
                        break;
                     case VertexType.EMX:
                        if ((p!=null) && (q!=null))
                        {
                           p.add_left( ix, iy);
                           out_poly.merge_right(p, q);
                           e0.outp[ABOVE]= null;
                           e1.outp[ABOVE]= null;
                        }
                        break;
                     case VertexType.IMN:
                        e0.outp[ABOVE] = out_poly.add_local_min(ix, iy);
                        e1.outp[ABOVE]= e0.outp[ABOVE];
                        break;
                     case VertexType.ILI:
                        if (p != null)
                        {
                           p.add_left(ix, iy);
                           e1.outp[ABOVE]= p;
                           e0.outp[ABOVE]= null;
                        }
                        break;
                     case VertexType.IRI:
                        if (q!=null)
                        {
                           q.add_right(ix, iy);
                           e0.outp[ABOVE]= q;
                           e1.outp[ABOVE]= null;
                        }
                        break;
                     case VertexType.IMX:
                        if ((p!=null) && (q!=null))
                        {
                           p.add_right(ix, iy);
                           out_poly.merge_left(p, q);
                           e0.outp[ABOVE]= null;
                           e1.outp[ABOVE]= null;
                        }
                        break;
                     case VertexType.IMM:
                        if ((p!=null) && (q!=null))
                        {
                           p.add_right(ix, iy);
                           out_poly.merge_left(p, q);
                           e0.outp[ABOVE] = out_poly.add_local_min(ix, iy);
                           e1.outp[ABOVE]= e0.outp[ABOVE];
                        }
                        break;
                     case VertexType.EMM:
                        if ((p!=null) && (q!=null))
                        {
                           p.add_left(ix, iy);
                           out_poly.merge_right(p, q);
                           e0.outp[ABOVE] = out_poly.add_local_min(ix, iy);
                           e1.outp[ABOVE] = e0.outp[ABOVE];
                        }
                        break;
                     default:
                        break;
                  } /* End of switch */
               } /* End of contributing intersection conditional */                  
                  
               /* Swap bundle sides in response to edge crossing */
               if (e0.bundle[ABOVE][CLIP]!=0)
                  e1.bside[CLIP] = (e1.bside[CLIP]==0)?1:0;
               if (e1.bundle[ABOVE][CLIP]!=0)
                  e0.bside[CLIP]= (e0.bside[CLIP]==0)?1:0;
               if (e0.bundle[ABOVE][SUBJ]!=0)
                  e1.bside[SUBJ]= (e1.bside[SUBJ]==0)?1:0;
               if (e1.bundle[ABOVE][SUBJ]!=0)
                  e0.bside[SUBJ]= (e0.bside[SUBJ]==0)?1:0;

               /* Swap e0 and e1 bundles in the AET */
               EdgeNode prev_edge = e0.prev;
               EdgeNode next_edge = e1.next;
               if (next_edge != null)
               {
                  next_edge.prev = e0;
               }
   
               if (e0.bstate[ABOVE] == BundleState.BUNDLE_HEAD)
               {
                  boolean search = true;
                  while (search)
                  {
                     prev_edge= prev_edge.prev;
                     if (prev_edge != null)
                     {
                        if (prev_edge.bstate[ABOVE] != BundleState.BUNDLE_TAIL)
                        {
                           search= false;
                        }
                     }
                     else
                     {
                        search= false;
                     }
                  }
               }
               if (prev_edge == null)
               {
                  aet.top_node.prev = e1;
                  e1.next           = aet.top_node;
                  aet.top_node      = e0.next;
               }
               else
               {
                  prev_edge.next.prev = e1;
                  e1.next             = prev_edge.next;
                  prev_edge.next      = e0.next;
               }
               e0.next.prev = prev_edge;
               e1.next.prev = e1;
               e0.next      = next_edge;
               if( DEBUG )
               {
                  out_poly.print();
               }
            } /* End of IT loop*/
}
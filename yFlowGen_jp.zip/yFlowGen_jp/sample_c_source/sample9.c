void hoge(){
	int x;
	if(1){
	 a=1;
		if(2){
			if(3){
				a=1;	//test1	
			}
		}
	}
	{
		if(4){
			if(5){
				a=1;	//test2
			}
		}
	}
	a=1;
}

void hoge2(){
	int x;
	{{if(1){
			 a=1;
				if(2){
					if(3){
						a=1;	//test1	
					}
				}}}
		{
			if(4){
				{
					if(5){
						a=1;	//test2
					}
				}
			}
		}
		
		for(i=0;i<100;i++){
			printf("TEST\n");
		}
		a=1;
	}
}
